package com.senai.starwars.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.starwars.api.entities.Personagem;

public interface PersonagemRepository extends JpaRepository<Personagem, Long> {
}