package com.senai.starwars.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.senai.starwars.api.entities.Personagem;
import com.senai.starwars.api.repository.PersonagemRepository;

import java.util.List;

@RestController
@RequestMapping("/api/personagens")
@CrossOrigin(origins = "*") // Permite acesso de qualquer frontend
public class PersonagemController {

    @Autowired
    private PersonagemRepository repository;

    // Listar todos
    @GetMapping
    public List<Personagem> listar() {
        return repository.findAll();
    }

    // Criar novo
    @PostMapping
    public Personagem criar(@RequestBody Personagem personagem) {
        return repository.save(personagem);
    }
}