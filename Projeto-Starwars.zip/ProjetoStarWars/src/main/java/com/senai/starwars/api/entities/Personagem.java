package com.senai.starwars.api.entities;

import jakarta.persistence.*;
import lombok.Data;

@Data // Gera Getters, Setters, etc. automaticamente (Lombok)
@Entity
@Table(name = "personagens")
public class Personagem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    
    @Column(name = "lado_da_forca")
    private String ladoDaForca; // Luz, Cinza, Sombrio
    
    private String ocupacao;    // Jedi, Sith, etc.
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getLadoDaForca() {
		return ladoDaForca;
	}
	public void setLadoDaForca(String ladoDaForca) {
		this.ladoDaForca = ladoDaForca;
	}
	public String getOcupacao() {
		return ocupacao;
	}
	public void setOcupacao(String ocupacao) {
		this.ocupacao = ocupacao;
	}
    
    
}