package com.senai.starwars.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoStarWarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoStarWarsApplication.class, args);
	}

}
